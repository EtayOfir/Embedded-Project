-- ============================================================
-- Project   : Home Alarm System - Full System Testbench
-- File Name : HA_System_TB.vhd
-- Author    : Etay Ofir and Yuval Shahar
-- ID        : 203844261 , 209455112
-- Created   : 10/12/2025
--
-- Description:
-- Testbench for the complete Home Alarm System.
-- Checks that all modules work together correctly:
-- sensors, button input, code handling, alarm FSM,
-- and display output.
--
-- Notes:
-- * Clock period is 10 ns.
-- * Uses a common check(...) procedure:
--   PASS is reported with "report", FAIL with "assert".
-- * Tests reset behavior: display_data, alarm_siren and system_armed are 'Z' during reset.
-- * Tests intrusion detection (2 sensors stable for debounce).
-- * Tests correct code entry using 8 presses (current SECRET_CODE = 00000000).
-- * Tests wrong code attempts by entering 7 wrong full codes (8-bit each) to trigger alarm/LOCKED.
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity HA_System_TB is
end HA_System_TB;

architecture tb of HA_System_TB is
    signal clk          : std_logic := '0';
    signal rst          : std_logic := '0';
    signal pass_btn     : std_logic := '0';
    signal door_sens    : std_logic := '0';
    signal window_sens  : std_logic := '0';
    signal motion_sens  : std_logic := '0';

    signal alarm_siren    : std_logic;
    signal system_armed   : std_logic;
    signal display_data   : std_logic_vector(7 downto 0);
    signal state_code_dbg : std_logic_vector(2 downto 0);

    constant Tclk : time := 10 ns;

    procedure check(cond : boolean; pass_msg : string; fail_msg : string) is
    begin
        if cond then
            report "PASS: " & pass_msg severity note;
        else
            assert false report "FAIL: " & fail_msg severity error;
        end if;
    end procedure;

    procedure wait_clocks(n : natural) is
    begin
        for i in 1 to n loop
            wait until rising_edge(clk);
            wait for 0 ns;
        end loop;
    end procedure;

    -- short press -> bit 0  (press < K clocks, K=3)
    procedure press_short(signal btn : out std_logic) is
    begin
        btn <= '1';
        wait_clocks(1);
        btn <= '0';
        wait_clocks(4);
    end procedure;

    -- long press -> bit 1 (press >= K clocks, K=3)
    procedure press_long(signal btn : out std_logic) is
    begin
        btn <= '1';
        wait_clocks(3);
        btn <= '0';
        wait_clocks(4);
    end procedure;

    -- enter an 8-bit code as 8 presses
    procedure enter_code_all_zeros(signal btn : out std_logic) is
    begin
        for i in 1 to 8 loop
            press_short(btn); -- generates 0
        end loop;
    end procedure;

    procedure enter_code_all_ones(signal btn : out std_logic) is
    begin
        for i in 1 to 8 loop
            press_long(btn); -- generates 1
        end loop;
    end procedure;

begin
    clk_proc : process
    begin
        while true loop
            clk <= '0'; wait for Tclk/2;
            clk <= '1'; wait for Tclk/2;
        end loop;
    end process;

    DUT: entity work.HA_System
        port map (
            clk            => clk,
            rst            => rst,
            pass_btn       => pass_btn,
            door_sens      => door_sens,
            window_sens    => window_sens,
            motion_sens    => motion_sens,
            alarm_siren    => alarm_siren,
            system_armed   => system_armed,
            display_data   => display_data,
            state_code_dbg => state_code_dbg
        );

    stim : process
    begin
        report "=== HA_System TB start ===" severity note;

        -- Reset: outputs must be Z during rst
        rst <= '1';
        wait for 2 ns;

        check(display_data = "ZZZZZZZZ" and alarm_siren='Z' and system_armed='Z',
              "Outputs are Z during reset",
              "Outputs not Z during reset");

        check(state_code_dbg = "ZZZ",
              "state_code_dbg is Z during reset",
              "state_code_dbg not Z during reset");

        rst <= '0';
        wait_clocks(3);

        check(system_armed='1',
              "System armed after reset release",
              "System not armed after reset release");

        -- Intrusion: need at least 2 sensors stable for debounce (3 clocks)
        report "=== Trigger intrusion (2 sensors) ===" severity note;
        door_sens   <= '1';
        window_sens <= '1';
        motion_sens <= '0';
        wait_clocks(4); -- >= debounce count (3)
		  wait_clocks(1); -- 1 clock to react to detected

        check(state_code_dbg = "110",
              "Debug shows door/window/motion = 1/1/0 during intrusion",
              "state_code_dbg mismatch during intrusion (expected 110)");

        check(alarm_siren='1',
              "Alarm siren ON after intrusion (2 sensors)",
              "Alarm siren did not turn ON after intrusion");

        -- clear sensors
        door_sens   <= '0';
        window_sens <= '0';
        motion_sens <= '0';
        wait_clocks(4); -- allow debounce to return to 0

        check(state_code_dbg = "000",
              "Debug returns to 000 after sensors cleared",
              "state_code_dbg did not return to 000 after sensors cleared");

        -- Correct code entry: Code_register expects 8 bits, SECRET_CODE=00000000
        report "=== Enter correct code (00000000) ===" severity note;
        enter_code_all_zeros(pass_btn);
        wait_clocks(6);

        check(alarm_siren='0',
              "Alarm OFF after correct code entry",
              "Alarm still ON after correct code entry");

        check(system_armed='0',
              "System disarmed after correct code",
              "System still armed after correct code");

        -- Wrong codes: 7 wrong full codes (each is 8 bits) -> LOCKED + siren latched ON
        report "=== 7 wrong codes (11111111) should trigger alarm/LOCKED ===" severity note;

        -- Re-arm by reset release behavior
        rst <= '1'; wait for 2 ns;
        rst <= '0'; wait_clocks(3);

        check(system_armed='1',
              "Re-armed after reset release",
              "Did not re-arm after reset release");

        -- Enter 7 wrong codes (each code is 8 ones => definitely != 00000000)
        for i in 1 to 7 loop
            enter_code_all_ones(pass_btn);
            wait_clocks(2);
        end loop;

        check(alarm_siren='1',
              "Alarm ON after 7 wrong codes",
              "Alarm did not turn ON after 7 wrong codes");

                assert true
          report "ALL TESTS PASSED SUCCESSFULLY"
          severity note;
        wait;

    end process;

end architecture;
