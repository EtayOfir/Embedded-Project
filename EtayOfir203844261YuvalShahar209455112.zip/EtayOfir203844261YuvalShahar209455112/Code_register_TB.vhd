-- ============================================================
-- Project   : Home Alarm System - Code Register Testbench
-- File Name : Code_register_TB.vhd
-- Author    : Etay Ofir and Yuval Shahar
-- ID        : 203844261 , 209455112
-- Created   : 28/11/2025
--
-- Description:
-- Testbench for the Code_register module.
-- Sends serial input bits, checks when the full code
-- is received, and verifies if the code matches.
--
-- Notes:
-- * Clock period: 10 ns.
-- * Reset is applied at the beginning.
-- * Test flow:
--   - Send a correct code sequence
--   - Send an incorrect code sequence
-- * 'valid' pulses are generated for each input bit.
-- * Prints the received code when code_ready = '1'.
-- ============================================================


library ieee;
use ieee.std_logic_1164.all;

entity Code_register_TB is
end Code_register_TB;

architecture sim of Code_register_TB is
    constant N : integer := 8;

    signal clk         : std_logic := '0';
    signal rst         : std_logic := '0';
    signal bit_in      : std_logic := '0';
    signal valid       : std_logic := '0';
    signal code_ready  : std_logic;
    signal code_match  : std_logic;
    signal code_vector : std_logic_vector(N-1 downto 0);


    -- Checker: provides BOTH report (PASS) and assert (FAIL)
    procedure check(cond : boolean; pass_msg : string; fail_msg : string) is
    begin
        if cond then
            report "PASS: " & pass_msg severity note;
        else
            assert false report "FAIL: " & fail_msg severity error;
        end if;
    end procedure;

    -- Convert std_logic_vector to string
    function slv_to_string(slv : std_logic_vector) return string is
        variable result : string(1 to slv'length);
        variable idx    : integer := 1;
    begin
        for i in slv'range loop
            result(idx) := std_logic'image(slv(i))(2);
            idx := idx + 1;
        end loop;
        return result;
    end function;


    -- Reverse a std_logic_vector for printing
    function reverse_slv(slv : std_logic_vector) return std_logic_vector is
        variable r : std_logic_vector(slv'range);
    begin
        for i in slv'range loop
            r(i) := slv(slv'left + slv'right - i);
        end loop;
        return r;
    end function;

begin

    -- Instantiate UUT
    UUT: entity work.Code_register
        port map(
            clk         => clk,
            rst         => rst,
            bit_in      => bit_in,
            valid       => valid,
            code_ready  => code_ready,
            code_match  => code_match,
            code_vector => code_vector
        );
		  

    -- Clock: 10 ns period
    clk_process : process
    begin
        loop
            clk <= '0';
            wait for 5 ns;
            clk <= '1';
            wait for 5 ns;
        end loop;
    end process;


    -- Test stimulus
    stim_proc: process
        -- First 8 bits: 00000000  (correct)
        -- Next  8 bits: 11110000  (wrong)
        variable test_seq : std_logic_vector(15 downto 0) := "1111000000000000";
        variable code_count : integer := 0;  -- counts completed codes
    begin
        -- Reset
        rst <= '1';
        wait for 20 ns;
        check(code_ready='Z' and code_match='Z' and code_vector = (code_vector'range => 'Z'),
            "Reset drives outputs to Z",
            "Reset did not drive outputs to Z");
        rst <= '0';
        wait until rising_edge(clk);
        check(code_vector /= (code_vector'range => 'Z'),
              "After reset deasserted, code_vector is driven",
              "code_vector stayed Z after reset deasserted");

        report "Starting test sequence: first correct, then wrong..." severity note;

        for i in 15 downto 0 loop
            bit_in <= test_seq(i);
            valid  <= '1';
            wait until rising_edge(clk);
            valid  <= '0';
            wait until rising_edge(clk);

            if code_ready = '1' then
                code_count := code_count + 1;

                report "---------------------------------------------";
                report "Code ready! Current vector = "
                       & slv_to_string(reverse_slv(code_vector));


                -- Formal checks using assert + report
                if code_count = 1 then
                    -- First code should be correct
                    check(code_match = '1',
                          "Correct code detected on first sequence",
                          "Expected code_match='1' for correct code");
                elsif code_count = 2 then
                    -- Second code should be wrong
                    check(code_match = '0',
                          "Wrong code detected on second sequence",
                          "Expected code_match='0' for wrong code");
                end if;
            end if;
        end loop;

        -- Final check: exactly two complete codes received
        check(code_count = 2,
              "Received exactly 2 complete codes",
              "Expected 2 complete codes (2 code_ready pulses)");

        report "Simulation finished successfully." severity note;
        wait;
    end process;

end sim;
