-- ============================================================
-- Project   : Home Alarm System - Sensors Logic Testbench
-- File Name : Sensors_logic_TB.vhd
-- Author    : Etay Ofir and Yuval Shahar
-- ID        : 203844261 , 209455112
-- Created   : 28/11/2025
--
-- Description:
-- Testbench for the Sensors_logic module.
-- Checks sensor debounce (3 clock cycles) and intrusion detection.
--
-- Notes:
-- * detected = '1' only when at least two sensors are active.
-- * Reset clears all clean outputs and detected signal.
-- * Uses a common check(...) procedure:
--   PASS with report, FAIL with assert.
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity Sensors_logic_TB is
end Sensors_logic_TB;

architecture tb of Sensors_Logic_TB is
    signal clk          : std_logic := '0';
    signal rst          : std_logic := '0';

    signal door_sens    : std_logic := '0';
    signal window_sens  : std_logic := '0';
    signal motion_sens  : std_logic := '0';

    signal door_clean   : std_logic;
    signal window_clean : std_logic;
    signal motion_clean : std_logic;
    signal detected     : std_logic;

    constant Tclk : time := 10 ns;

    -- Checker: provides BOTH report (PASS) and assert (FAIL)
    procedure check(cond : boolean; pass_msg : string; fail_msg : string) is
    begin
        if cond then
            report "PASS: " & pass_msg severity note;
        else
            assert false report "FAIL: " & fail_msg severity error;
        end if;
    end procedure;

    procedure wait_clocks(n : natural) is
    begin
        for i in 1 to n loop
            wait until rising_edge(clk);
        end loop;
    end procedure;

begin
    -- Clock
    clk_proc : process
    begin
        while true loop
            clk <= '0'; wait for Tclk/2;
            clk <= '1'; wait for Tclk/2;
        end loop;
    end process;

    -- DUT
    UUT: entity work.Sensors_logic
        port map (
            clk          => clk,
            rst          => rst,
            door_sens    => door_sens,
            window_sens  => window_sens,
            motion_sens  => motion_sens,
            door_clean   => door_clean,
            window_clean => window_clean,
            motion_clean => motion_clean,
            detected     => detected
        );

    stim : process
    begin
        report "=== Sensors_logic TB start ===" severity note;

        -- Reset
        rst <= '1';
        wait for 2 ns;              -- async reset response time
        check(door_clean='Z' and window_clean='Z' and motion_clean='Z' and detected='Z',
              "Reset drives clean/detected to 'Z'",
              "Reset did not drive clean/detected to 'Z'");
        rst <= '0';
        wait_clocks(2);

        -- 1) Noise shorter than 3 clocks should NOT pass debounce
        report "=== Test 1: Noise rejected ===" severity note;
        door_sens <= '1'; wait_clocks(2);   -- only 2 clocks high (X=3 needed)
        door_sens <= '0'; wait_clocks(2);
        check(door_clean='0',
              "Door noise (<3 clocks) did not set door_clean",
              "Door noise incorrectly set door_clean");

        -- 2) Stable 1 for 3 clocks should set clean
        report "=== Test 2: Debounce accept ===" severity note;
        door_sens <= '1'; wait_clocks(3);
        check(door_clean='1',
              "Door stable 1 for 3 clocks sets door_clean",
              "Door stable 1 did not set door_clean");

        -- Only one sensor clean -> detected must be 0
        check(detected='0',
              "Detected remains 0 when only one sensor is active",
              "Detected became 1 with only one sensor active");

        -- 3) Second sensor stable -> detected must become 1
        report "=== Test 3: detected requires 2 sensors ===" severity note;
        window_sens <= '1'; wait_clocks(3);
        check(window_clean='1',
              "Window stable 1 sets window_clean",
              "Window stable 1 did not set window_clean");

        check(detected='1',
              "Detected becomes 1 when two sensors are active",
              "Detected did not become 1 with two sensors active");

        -- 4) Drop one sensor -> detected must drop to 0 (since now only one remains)
        report "=== Test 4: detected drops when <2 sensors ===" severity note;
        window_sens <= '0'; wait_clocks(3);
        check(window_clean='0',
              "Window returns clean to 0 after stable low",
              "Window clean did not return to 0");

        check(detected='0',
              "Detected returns to 0 when fewer than two sensors are active",
              "Detected stayed 1 with only one sensor active");

        report "=== ALL TESTS DONE (Sensors_logic) ===" severity note;
        wait;
    end process;

end architecture;
