-- ============================================================
-- Project   : Home Alarm System - Alarm Control Testbench
-- File Name : alarm_Control_TB.vhd
-- Author    : Etay Ofir and Yuval Shahar
-- ID        : 203844261 , 209455112
-- Created   : 16/12/2025
--
-- Description:
-- Testbench for the alarm_Control module.
-- Tests the alarm FSM behavior, including reset,
-- arming, intrusion detection, wrong code attempts,
-- LOCKED state, and correct code entry.
--
-- Notes:
-- * Clock period: 10 ns.
-- * System starts in ARMED state after reset
--   (according to the assignment).
-- * Test flow / coverage:
--   1) Reset behavior: all std_logic outputs drive 'Z' during rst='1',
--      then system returns to ARMED after reset release.
--   2) Intrusion triggers alarm; siren is latched and reset does NOT clear it
--      (reset drives outputs to 'Z' only while asserted).
--   3) Wrong code attempts counting:
--      - After 3 wrong attempts: NOT LOCKED (threshold is 7).
--      - After 7 wrong attempts: enter LOCKED and siren remains ON (latched).
--   4) LOCKED duration: remains locked ~5 cycles, then releases and attempts reset to 0.
--   5) Correct code clears siren latch and disarms the system.
--   6) 7 wrong attempts while DISARMED also triggers LOCKED + latched siren.
-- ============================================================

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity alarm_Control_TB is
end alarm_Control_TB;

architecture tb of alarm_Control_TB is
    signal clk                : std_logic := '0';
    signal rst                : std_logic := '0';
    signal intrusion_detected : std_logic := '0';
    signal code_ready         : std_logic := '0';
    signal code_match         : std_logic := '0';

    signal enable_press       : std_logic;
    signal clear_code         : std_logic;
    signal alarm_siren        : std_logic;
    signal system_armed       : std_logic;
    signal state_code         : std_logic_vector(2 downto 0);
    signal attempts           : integer range 0 to 7;

    constant Tclk : time := 10 ns;

    procedure check(cond : boolean; pass_msg : string; fail_msg : string) is
    begin
        if cond then
            report "PASS: " & pass_msg severity note;
        else
            assert false report "FAIL: " & fail_msg severity error;
        end if;
    end procedure;

    procedure wait_clocks(n : natural) is
    begin
        for i in 1 to n loop
            wait until rising_edge(clk);
            wait for 0 ns;
        end loop;
    end procedure;

    procedure pulse_code(is_match : std_logic) is
    begin
        code_ready <= '1';
        code_match <= is_match;
        wait_clocks(1);
        code_ready <= '0';
        code_match <= '0';
        wait_clocks(1);
    end procedure;

begin
    clk_proc : process
    begin
        while true loop
            clk <= '0'; wait for Tclk/2;
            clk <= '1'; wait for Tclk/2;
        end loop;
    end process;

    UUT: entity work.alarm_Control
        port map (
            clk                => clk,
            rst                => rst,
            intrusion_detected => intrusion_detected,
            code_ready         => code_ready,
            code_match         => code_match,
            enable_press       => enable_press,
            clear_code         => clear_code,
            alarm_siren        => alarm_siren,
            system_armed       => system_armed,
            state_code         => state_code,
            attempts           => attempts
        );

    stim : process
    begin
        report "=== alarm_Control TB start ===" severity note;

        -- Step 1: Reset behavior (outputs to Z during reset, ARMED after)
        report "=== Step 1: reset checks ===" severity note;
        rst <= '1';
        wait for 2 ns; -- async response

        check(enable_press = 'Z' and clear_code = 'Z' and alarm_siren = 'Z' and system_armed = 'Z'
              and state_code = (others => 'Z'),
              "During reset: std_logic outputs are Z",
              "During reset: outputs not Z as required");

        rst <= '0';
        wait_clocks(2);

        check(system_armed = '1',
              "System armed after reset release",
              "Expected system_armed='1' after reset release");

        check(state_code = "001",
              "State is ARMED after reset release (001)",
              "Expected state_code=001 (ARMED) after reset release");

        -- Step 2: Intrusion -> alarm, siren latched; reset must NOT stop siren
        report "=== Step 2: intrusion -> alarm + latch ===" severity note;
        intrusion_detected <= '1';
        wait_clocks(1);
        intrusion_detected <= '0';
        wait_clocks(1);

        check(alarm_siren = '1',
              "Alarm siren ON after intrusion",
              "Expected alarm_siren='1' after intrusion");

        -- Apply reset while alarm is active: outputs go Z DURING reset,
        -- but after reset release siren must return ON because latch has no reset.
        rst <= '1';
        wait for 2 ns;
        check(alarm_siren = 'Z',
              "During reset: alarm_siren is Z (displayed as Z on outputs)",
              "During reset: alarm_siren not Z");

        rst <= '0';
        wait_clocks(2);
        check(alarm_siren = '1',
              "After reset release: siren still ON (latched)",
              "Siren incorrectly cleared by reset");


        -- Step 3: Wrong codes x3 should NOT lock yet (since threshold is 7)
        report "=== Step 3: wrong code x3 (should not LOCK yet) ===" severity note;
        for i in 1 to 3 loop
            pulse_code('0');
        end loop;

        check(attempts = 3,
              "Attempts counted to 3",
              "Attempts did not count to 3 after 3 wrong codes");

        check(state_code /= "011",
              "Not in LOCKED after only 3 wrong attempts",
              "Entered LOCKED too early (should be at 7)");


        -- Step 4: Continue wrong codes to reach 7 -> LOCKED + siren stays ON
        report "=== Step 4: wrong code to 7 -> LOCKED ===" severity note;
        for i in 4 to 7 loop
            pulse_code('0');
        end loop;

        check(attempts = 7,
              "Attempts reached 7",
              "Attempts did not reach 7");

        check(state_code = "011",
              "LOCKED state entered at 7 wrong attempts (011)",
              "Expected LOCKED state_code=011 at 7 wrong attempts");

        check(enable_press = '0',
              "enable_press disabled in LOCKED",
              "enable_press should be 0 in LOCKED");

        check(alarm_siren = '1',
              "Siren ON while LOCKED (latched)",
              "Siren should be ON while LOCKED/latched");


        -- Step 5: LOCKED timing 5 cycles then release + attempts reset
        -- After 4 cycles still locked; after 6 cycles released
        report "=== Step 5: LOCKED duration check ===" severity note;
        wait_clocks(4);
        check(state_code = "011",
              "Still LOCKED after 4 clocks",
              "LOCKED released too early");

        wait_clocks(2);
        check(state_code /= "011",
              "LOCKED released after ~5 clocks (checked after 6)",
              "LOCKED did not release after expected time");

        check(attempts = 0,
              "Attempts reset to 0 after LOCKED timeout",
              "Attempts did not reset after LOCKED timeout");


        -- Step 6: Correct code clears siren latch and disarms
        report "=== Step 6: correct code clears siren + disarms ===" severity note;
        pulse_code('1');

        check(alarm_siren = '0',
              "Alarm OFF after correct code",
              "Expected alarm_siren='0' after correct code");

        check(system_armed = '0',
              "System disarmed after correct code",
              "Expected system_armed='0' after correct code");

        check(state_code = "000",
              "State is DISARMED after correct code (000)",
              "Expected state_code=000 (DISARMED) after correct code");


        -- Step 7: 7 wrong attempts while DISARMED triggers LOCKED + siren
        report "=== Step 7: 7 wrong attempts in DISARMED triggers alarm/LOCKED ===" severity note;
        for i in 1 to 7 loop
            pulse_code('0');
        end loop;

        check(state_code = "011",
              "LOCKED entered from DISARMED after 7 wrong attempts",
              "Expected LOCKED after 7 wrong attempts in DISARMED");

        check(alarm_siren = '1',
              "Siren latched ON due to 7 wrong attempts",
              "Expected siren ON after 7 wrong attempts");

        report "=== ALL TESTS DONE (alarm_Control) ===" severity note;
        wait;
    end process;

end architecture;
