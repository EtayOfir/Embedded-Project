-- ============================================================
-- Project   : Home Alarm System - Display Data Testbench
-- File Name : Display_data_TB.vhd
-- Author    : Etay Ofir and Yuval Shahar
-- ID        : 203844261 , 209455112
-- Created   : 28/11/2025
--
-- Description:
-- Testbench for the Display_data module.
-- Checks that the display shows the correct values
-- for different system states and number of attempts.
--
-- Notes:
-- * Clock period: 10 ns.
-- * Uses report + assert via check(...) procedure.
-- * Display_data must output 'Z' during rst='1'.
-- * Alarm persistence is handled by alarm_Control, not by Display_data.
-- ============================================================

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity Display_data_TB is
end Display_data_TB;

architecture rtl of Display_data_TB is
    signal clk        : std_logic := '0';
    signal rst        : std_logic := '0';
    signal state_code : std_logic_vector(2 downto 0) := "000";
    signal attempts   : integer range 0 to 7 := 0;
    signal data       : std_logic_vector(7 downto 0);
	 signal success_pulse : std_logic := '0';

    constant clk_period : time := 10 ns;

    -- Match Display_data.vhd mapping
    constant ST_DISARMED : std_logic_vector(2 downto 0) := "000";
    constant ST_ARMED    : std_logic_vector(2 downto 0) := "001";
    constant ST_ALARM    : std_logic_vector(2 downto 0) := "010";
    constant ST_LOCKED   : std_logic_vector(2 downto 0) := "011";

    constant DISP_OFF     : std_logic_vector(7 downto 0) := x"00";
    constant DISP_ARMED   : std_logic_vector(7 downto 0) := x"08";
    constant DISP_ALARM   : std_logic_vector(7 downto 0) := x"0A";
    constant DISP_SUCCESS : std_logic_vector(7 downto 0) := x"0F"; -- shown when success_pulse='1'
	 
	 -- Helper constant: represents 'Z' on 8-bit display
	 constant Z8 : std_logic_vector(7 downto 0) := (others => 'Z');
	 
    -- Checker: provides BOTH report (PASS) and assert (FAIL)
    procedure check(cond : boolean; pass_msg : string; fail_msg : string) is
    begin
        if cond then
            report "PASS: " & pass_msg severity note;
        else
            assert false report "FAIL: " & fail_msg severity error;
        end if;
    end procedure;

begin
    -- Instantiate DUT (updated ports)
    DUT: entity work.Display_data
        port map(
            clk           => clk,
            rst           => rst,
            state_code    => state_code,
            attempts      => attempts,
				success_pulse => success_pulse,
            data          => data
        );

    -- Clock generation
    clk_process : process
    begin
        loop
            clk <= '0';
            wait for clk_period / 2;
            clk <= '1';
            wait for clk_period / 2;
        end loop;
    end process;

    -- Test stimulus
    stim_proc: process
    begin
	 
        -- Initial reset: data must be Z
        report "Applying initial reset..." severity note;
        rst <= '1';
        wait for 2 ns; -- async response time
        check(data = Z8,
              "During reset, data is Z",
              "During reset, data is NOT Z");

        rst <= '0';
        wait until rising_edge(clk);
        wait for 0 ns;

        -- DISARMED -> OFF (0)
        state_code <= ST_DISARMED;
        attempts   <= 0;
        wait until rising_edge(clk);
        wait for 0 ns;
        check(data = DISP_OFF,
              "DISARMED displays OFF (0)",
              "DISARMED display mismatch");

        -- ARMED -> 8
        state_code <= ST_ARMED;
        wait until rising_edge(clk);
        wait for 0 ns;
        check(data = DISP_ARMED,
              "ARMED displays 8",
              "ARMED display mismatch");

        -- ALARM -> A
        state_code <= ST_ALARM;
        wait until rising_edge(clk);
        wait for 0 ns;
        check(data = DISP_ALARM,
              "ALARM displays A",
              "ALARM display mismatch");

        -- Reset while in ALARM:
        -- Display must go Z during reset, then return to A after reset release.
        rst <= '1';
        wait for 2 ns;
        check(data = Z8,
              "Reset forces display Z even during ALARM",
              "Display not Z during reset");

        rst <= '0';
        wait until rising_edge(clk);
        wait for 0 ns;
        check(data = DISP_ALARM,
              "After reset release, ALARM display returns to A",
              "After reset release, ALARM display did not return to A");

        -- LOCKED -> A (same as alarm)
        state_code <= ST_LOCKED;
        wait until rising_edge(clk);
        wait for 0 ns;
        check(data = DISP_ALARM,
              "LOCKED displays A",
              "LOCKED display mismatch");
		  
		  -- SUCCESS pulse, display F for that cycle
		  success_pulse <= '1';
		  wait until rising_edge(clk);
		  wait for 0 ns;
		  check(data = DISP_SUCCESS,
		  		"SUCCESS pulse displays F",
		  		"SUCCESS pulse did not display F");

		  success_pulse <= '0';
		  wait until rising_edge(clk);
		  wait for 0 ns;
		  -- return to normal
		  check(data = DISP_ALARM,
				"After SUCCESS pulse, display returns to normal (LOCKED->A)",
				"Display did not return to normal after SUCCESS pulse");
        -- Attempts display: (Display_data shows attempts only for 'others')
        report "Testing attempts display via 'others' state_code..." severity note;

        -- Use an undefined code "100" to hit the 'others'
        state_code <= "100";
        for i in 1 to 7 loop
            attempts <= i;
            wait until rising_edge(clk);
            wait for 0 ns;

            check(data = ("0000" & std_logic_vector(to_unsigned(i, 4))),
						"Attempts=" & integer'image(i) & " displayed",
						"Attempts display mismatch for " & integer'image(i));
        end loop;

        -- attempts=0 should fall back to OFF
        attempts <= 0;
        wait until rising_edge(clk);
        wait for 0 ns;
        check(data = DISP_OFF,
              "Attempts=0 falls back to OFF",
              "Attempts=0 did not fall back to OFF");

        -- Final reset check
        rst <= '1';
        wait for 2 ns;
        check(data = Z8,
              "Final reset drives data to Z",
              "Final reset did not drive data to Z");

        report "=== ALL TESTS DONE (Display_data) ===" severity note;
        wait;
    end process;

end rtl;
