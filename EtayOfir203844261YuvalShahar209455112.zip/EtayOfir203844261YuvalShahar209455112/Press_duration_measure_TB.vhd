-- ============================================================
-- Project   : Home Alarm System - Press Duration Measure Testbench
-- File Name : Press_duration_measure_TB.vhd
-- Author    : Etay Ofir and Yuval Shahar
-- ID        : 203844261 , 209455112
-- Created   : 28/11/2025
--
-- Description:
-- Testbench for the Press_duration_measure module.
-- Checks how button press length is translated into bits.
--
-- Notes:
-- * Clock period: 10 ns.
-- * Measurement starts when enable = '1'.
-- * Short press (< K clocks) gives bit_out = '0'.
-- * Long press (>= K clocks) gives bit_out = '1'.
-- * bit_valid is a one-clock pulse at the end of each press.
-- * Uses a common check(...) procedure
--   (PASS with report, FAIL with assert).
-- ============================================================

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity Press_duration_measure_TB is
end Press_duration_measure_TB;

architecture tb of Press_duration_measure_TB is
    signal clk       : std_logic := '0';
    signal rst       : std_logic := '0';
    signal btn_in    : std_logic := '0';
    signal enable    : std_logic := '0';
    signal bit_out   : std_logic;
    signal bit_valid : std_logic;

    constant Tclk : time := 10 ns;

    procedure check(cond : boolean; pass_msg : string; fail_msg : string) is
    begin
        if cond then
            report "PASS: " & pass_msg severity note;
        else
            assert false report "FAIL: " & fail_msg severity error;
        end if;
    end procedure;

    procedure wait_clocks(n : natural) is
    begin
        for i in 1 to n loop
            wait until rising_edge(clk);
        end loop;
    end procedure;

begin
    clk_proc : process
    begin
        while true loop
            clk <= '0'; wait for Tclk/2;
            clk <= '1'; wait for Tclk/2;
        end loop;
    end process;

    UUT: entity work.Press_duration_measure
        port map (
            clk       => clk,
            rst       => rst,
            btn_in    => btn_in,
            enable    => enable,
            bit_out   => bit_out,
            bit_valid => bit_valid
        );

    stim : process
    begin
        report "=== Press_duration_measure TB start ===" severity note;

        -- Reset
        rst <= '1';
        wait for 2 ns;
        check(bit_out = 'Z' and bit_valid = 'Z',
            "Reset drives bit_out/bit_valid to Z",
            "Reset did not drive bit_out/bit_valid to Z");
        rst <= '0';
        wait_clocks(2);
        -- enable=0 should ignore presses (bit_valid should not pulse)
        report "=== Test 1: enable=0 ignores press ===" severity note;
        enable <= '0';
        btn_in <= '1'; wait_clocks(5);
        btn_in <= '0'; wait_clocks(2);
        check(bit_valid='0',
              "No bit_valid pulse when enable=0",
              "bit_valid pulsed even though enable=0");

        -- Short press: 2 clocks (<3) => bit_out=0 and bit_valid=1 for one clock
        report "=== Test 2: short press => 0 ===" severity note;
        enable <= '1';
        btn_in <= '1'; wait_clocks(2);
        btn_in <= '0';
        wait until rising_edge(clk);
        check(bit_valid='1' and bit_out='0',
              "Short press produced bit_out=0 with bit_valid pulse",
              "Short press did not produce expected (bit_valid=1, bit_out=0)");
        wait until rising_edge(clk);
        check(bit_valid='0',
              "bit_valid returned to 0 after one cycle",
              "bit_valid was not one-cycle pulse");

        -- Long press: 3 clocks (>=3) => bit_out=1
        report "=== Test 3: long press => 1 ===" severity note;
        btn_in <= '1'; wait_clocks(3);
        btn_in <= '0';
        wait until rising_edge(clk);
        check(bit_valid='1' and bit_out='1',
              "Long press produced bit_out=1 with bit_valid pulse",
              "Long press did not produce expected (bit_valid=1, bit_out=1)");
        wait until rising_edge(clk);
        check(bit_valid='0',
              "bit_valid returned to 0 after one cycle (long press)",
              "bit_valid was not one-cycle pulse (long press)");

        report "=== ALL TESTS DONE (Press_duration_measure) ===" severity note;
        wait;
    end process;

end architecture;
