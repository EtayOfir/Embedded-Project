-- ============================================================
-- Project   : Home Alarm System - Top Level
-- File Name : HA_System.vhd
-- Author    : Etay Ofir and Yuval Shahar
-- ID        : 203844261 , 209455112
-- Created   : 10/12/2025
--
-- Description:
-- Top-level integration module for the Home Alarm System.
-- Connects sensors, button press logic, code register,
-- alarm control FSM, and display logic into a single system.
--
-- Notes:
-- * Acts as the main system wrapper.
-- * Handles internal signal routing between modules.
-- * Provides debug outputs for sensor states.
-- * Designed for simulation and FPGA synthesis.
-- * std_logic outputs drive 'Z' during rst='1'.
-- * clear_code is used by Controller, not used for reset Code register.
-- * Code_register reset is driven only by rst.
-- * state_code_dbg outputs the cleaned sensor states (door/window/motion) as 3 bits.
-- * Wrong code attempts threshold is 7 (locked/alarm after 7 wrong attempts).
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity HA_System is
    port (
        clk            : in  std_logic;
        rst            : in  std_logic;

        pass_btn        : in  std_logic;
        door_sens       : in  std_logic;
        window_sens     : in  std_logic;
        motion_sens     : in  std_logic;

        alarm_siren    : out std_logic;
        system_armed   : out std_logic;
        display_data   : out std_logic_vector(7 downto 0);

        state_code_dbg : out std_logic_vector(2 downto 0)
    );
end HA_System;

architecture rtl of HA_System is
    -- Sensors
    signal door_clean_s, window_clean_s, motion_clean_s : std_logic;
    signal intrusion_detected_s : std_logic;

    -- Press duration -> serial bits
    signal bit_out_s, bit_valid_s : std_logic;

    -- Code register outputs
    signal code_ready_s, code_match_s : std_logic;
    signal code_vector_s : std_logic_vector(7 downto 0);

    -- Controller outputs
    signal enable_press_s : std_logic;
    signal clear_code_s   : std_logic;
    signal attempts_s     : integer range 0 to 7;
    signal state_code_s   : std_logic_vector(2 downto 0);

    -- Internal reset ONLY for Code_register
    signal rst_code_reg_s : std_logic;
	 
	 -- Display helper
	 signal success_pulse_s : std_logic;
	 
begin
    
    -- Debug: show cleaned sensors on 3-bit output (door, window, motion)
    state_code_dbg <= door_clean_s & window_clean_s & motion_clean_s;

    -- clear_code resets ONLY the Code_register
    rst_code_reg_s <= rst;
	 
	 -- Success pulse: correct code entered
	 success_pulse_s <= code_ready_s and code_match_s;

    -- Sensors logic (debounce + detected)
    u_sensors: entity work.Sensors_logic
        port map (
            clk          => clk,
            rst          => rst,
            door_sens    => door_sens,
            window_sens  => window_sens,
            motion_sens  => motion_sens,
            door_clean   => door_clean_s,
            window_clean => window_clean_s,
            motion_clean => motion_clean_s,
            detected     => intrusion_detected_s
        );

    -- Press duration measure (button -> bits)
    u_press: entity work.Press_duration_measure
        port map (
            clk       => clk,
            rst       => rst,
            btn_in    => pass_btn,
            enable    => enable_press_s,
            bit_out   => bit_out_s,
            bit_valid => bit_valid_s
        );

    -- Code register (collect 8 bits)
    u_code: entity work.Code_register
        port map (
            clk         => clk,
            rst         => rst_code_reg_s,
            bit_in      => bit_out_s,
            valid       => bit_valid_s,
            code_ready  => code_ready_s,
            code_match  => code_match_s,
            code_vector => code_vector_s
        );

    -- Alarm controller (FSM)
    u_ctrl: entity work.alarm_Control
        port map (
            clk                => clk,
            rst                => rst,
            intrusion_detected => intrusion_detected_s,
            code_ready         => code_ready_s,
            code_match         => code_match_s,
            enable_press       => enable_press_s,
            clear_code         => clear_code_s,
            alarm_siren        => alarm_siren,
            system_armed       => system_armed,
            attempts           => attempts_s,
            state_code         => state_code_s
        );

    -- Display data
    u_disp: entity work.Display_data
        port map (
            clk        	  => clk,
            rst        	  => rst,
            state_code 	  => state_code_s,
            attempts   	  => attempts_s,
				success_pulse => success_pulse_s,
            data       	  => display_data
        );

end rtl;
