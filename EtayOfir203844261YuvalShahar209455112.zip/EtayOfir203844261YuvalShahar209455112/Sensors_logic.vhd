-- ============================================================
-- Project   : Home Alarm System - Sensors Logic
-- File Name : Sensors_logic.vhd
-- Author    : Etay Ofir and Yuval Shahar
-- ID        : 203844261 , 209455112
-- Created   : 28/11/2025
--
-- Description:
-- Sensor processing module for door, window, and motion sensors.
-- Performs debouncing and generates a clean intrusion_detected
-- signal when at least two sensors are activated.
--
-- Notes:
-- * Inputs are raw sensor signals.
-- * Outputs are debounced clean sensor signals.
-- * Intrusion is detected after stable activation
--   for a predefined number of clock cycles.
-- * Used as input to the alarm control FSM.
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;

entity Sensors_logic is
  port (
    -- clock and reset signals
    clk          : in  std_logic;
    rst          : in  std_logic;

    -- raw sensor input signals (with noise)
    door_sens    : in  std_logic;
    window_sens  : in  std_logic;
    motion_sens  : in  std_logic;

    -- signals are "clean" after debounce
    door_clean   : out std_logic;
    window_clean : out std_logic;
    motion_clean : out std_logic;

    -- detected = 1 if at least 2 sensors are clean
    detected     : out std_logic
  );
end Sensors_logic;

architecture rtl of Sensors_logic is

  -- Number of consecutive clock cycles required to be considered "clean"
  constant DEBOUNCE_COUNT : integer := 3;

  -- Counters for each sensor (count consecutive clock cycles input is '1')
  signal cnt_door   : integer range 0 to DEBOUNCE_COUNT := 0;
  signal cnt_window : integer range 0 to DEBOUNCE_COUNT := 0;
  signal cnt_motion : integer range 0 to DEBOUNCE_COUNT := 0;

  -- Internal signals to hold clean states before assigning to outputs
  signal door_clean_int   : std_logic := '0';
  signal window_clean_int : std_logic := '0';
  signal motion_clean_int : std_logic := '0';
  signal detected_int     : std_logic := '0';


begin

  process (clk, rst)
    -- Next counter values (computed within the same clock cycle)
    variable next_door_cnt   : integer range 0 to DEBOUNCE_COUNT;
    variable next_window_cnt : integer range 0 to DEBOUNCE_COUNT;
    variable next_motion_cnt : integer range 0 to DEBOUNCE_COUNT;
	 
	 variable door_next_clean   : std_logic;
	 variable window_next_clean : std_logic;
	 variable motion_next_clean : std_logic;

  begin
    if rst = '1' then
      -- Asynchronous reset:
      cnt_door   <= 0;
      cnt_window <= 0;
      cnt_motion <= 0;

      door_clean_int   <= '0';
      window_clean_int <= '0';
      motion_clean_int <= '0';
      detected_int     <= '0';

    elsif rising_edge(clk) then


      -- 1) Compute NEXT counter values for each sensor
      --    Clean requires DEBOUNCE_COUNT consecutive HIGH samples.

      -- Door sensor next counter
      next_door_cnt := cnt_door;
      if door_sens = '1' then
        if next_door_cnt < DEBOUNCE_COUNT then
          next_door_cnt := next_door_cnt + 1;
        end if;
      else
        next_door_cnt := 0;
      end if;

      -- Window sensor next counter
      next_window_cnt := cnt_window;
      if window_sens = '1' then
        if next_window_cnt < DEBOUNCE_COUNT then
          next_window_cnt := next_window_cnt + 1;
        end if;
      else
        next_window_cnt := 0;
      end if;

      -- Motion sensor next counter
      next_motion_cnt := cnt_motion;
      if motion_sens = '1' then
        if next_motion_cnt < DEBOUNCE_COUNT then
          next_motion_cnt := next_motion_cnt + 1;
        end if;
      else
        next_motion_cnt := 0;
      end if;

      -- 2) Update counters (signals) using computed NEXT values
      cnt_door   <= next_door_cnt;
      cnt_window <= next_window_cnt;
      cnt_motion <= next_motion_cnt;


      -- 3) Update clean outputs based on NEXT values
      --    This ensures "exactly 3 consecutive cycles" behavior.
      if next_door_cnt >= DEBOUNCE_COUNT then
        door_clean_int <= '1';
      else
        door_clean_int <= '0';
      end if;

      if next_window_cnt >= DEBOUNCE_COUNT then
        window_clean_int <= '1';
      else
        window_clean_int <= '0';
      end if;

      if next_motion_cnt >= DEBOUNCE_COUNT then
        motion_clean_int <= '1';
      else
        motion_clean_int <= '0';
      end if;
		-- NEXT clean values (based on counters of this cycle)
      if next_door_cnt >= DEBOUNCE_COUNT then
        door_next_clean := '1';
      else
        door_next_clean := '0';
      end if;

      if next_window_cnt >= DEBOUNCE_COUNT then
        window_next_clean := '1';
      else
        window_next_clean := '0';
      end if;

      if next_motion_cnt >= DEBOUNCE_COUNT then
        motion_next_clean := '1';
      else
        motion_next_clean := '0';
      end if;

      -- 4) Intrusion detection:
      --    detected = '1' if at least two clean sensors are '1'
      if ( (door_next_clean   = '1' and window_next_clean = '1') or
           (door_next_clean   = '1' and motion_next_clean = '1') or
           (window_next_clean = '1' and motion_next_clean = '1') ) then
        detected_int <= '1';
      else
        detected_int <= '0';
      end if;

    end if;
  end process;
  -- Output connections with Z on reset
  door_clean   <= 'Z' when rst = '1' else door_clean_int;
  window_clean <= 'Z' when rst = '1' else window_clean_int;
  motion_clean <= 'Z' when rst = '1' else motion_clean_int;
  detected     <= 'Z' when rst = '1' else detected_int;


end rtl;
