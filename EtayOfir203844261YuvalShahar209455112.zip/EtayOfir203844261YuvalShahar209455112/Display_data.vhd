-- ============================================================
-- Project   : Home Alarm System - Display Data
-- File Name : Display_data.vhd
-- Author    : Etay Ofir and Yuval Shahar
-- ID        : 203844261 , 209455112
-- Created   : 10/12/2025
--
-- Description:
-- Drives the 7-seg display data (8-bit encoded) according to
-- the current system state and number of wrong attempts.
--
-- Display mapping:
--   0  -> OFF
--   8  -> ARMED
--   A  -> ALARM / Intrusion
--   F  -> Correct code (SUCCESS)
--   1..7 -> Number of wrong attempts (during code entry)
--
-- Notes:
-- * Asynchronous reset drives data to 'Z'.
-- * This module is display-only: no alarm latching inside.
-- ============================================================

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity Display_data is
    port (
        clk          : in  std_logic;
        rst          : in  std_logic;
        state_code   : in  std_logic_vector(2 downto 0);
        attempts     : in  integer range 0 to 7;
        success_pulse: in  std_logic;
        data         : out std_logic_vector(7 downto 0)
    );
end Display_data;

architecture rtl of Display_data is
    -- State codes must match alarm_Control
    constant ST_DISARMED : std_logic_vector(2 downto 0) := "000";
    constant ST_ARMED    : std_logic_vector(2 downto 0) := "001";
    constant ST_ALARM    : std_logic_vector(2 downto 0) := "010";
    constant ST_LOCKED   : std_logic_vector(2 downto 0) := "011";

    -- Display codes
    constant DISP_OFF     : std_logic_vector(7 downto 0) := x"00";
    constant DISP_ARMED   : std_logic_vector(7 downto 0) := x"08";
    constant DISP_ALARM   : std_logic_vector(7 downto 0) := x"0A";
    constant DISP_SUCCESS : std_logic_vector(7 downto 0) := x"0F";
begin

    process(clk, rst)
    begin
        if rst = '1' then
            data <= (others => 'Z');

        elsif rising_edge(clk) then

            -- Success has top priority
            if success_pulse = '1' then
                data <= DISP_SUCCESS;

            else
                -- Normal display selection
                case state_code is

                    when ST_DISARMED =>
                        data <= DISP_OFF;

                    when ST_ARMED =>
                        data <= DISP_ARMED;

                    when ST_ALARM | ST_LOCKED =>
                        data <= DISP_ALARM;

                    when others =>
                        if attempts >= 1 and attempts <= 7 then
                            data <= "0000" & std_logic_vector(to_unsigned(attempts, 4));
                        else
                            data <= DISP_OFF;
                        end if;

                end case;
            end if;

        end if;
    end process;

end rtl;
