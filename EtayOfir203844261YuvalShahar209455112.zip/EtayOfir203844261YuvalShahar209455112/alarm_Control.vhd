-- ============================================================
-- Project   : Home Alarm System - Alarm Control
-- File Name : alarm_Control.vhd
-- Author    : Etay Ofir and Yuval Shahar
-- ID        : 203844261 , 209455112
-- Created   : 10/12/2025
--
-- Description:
-- Finite State Machine (FSM) that controls the alarm system.
-- Handles arming/disarming, intrusion detection, alarm activation,
-- wrong code attempts counting, and LOCKED state.
--
-- Notes:
-- * Synchronous FSM with asynchronous reset.
-- * After reset: ARMED.
-- * After alarm is activated, reset does NOT stop the siren.
--   Siren is latched until a correct code is entered.
-- * Wrong attempts count up to 7. Reaching 7 triggers alarm/lock (even if DISARMED).
-- * LOCKED state lasts 5 clock cycles, then attempts reset and
--   code entry is allowed again.
-- * During rst='1', std_logic outputs drive 'Z'.
-- ============================================================

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity alarm_Control is
    port (
        clk                : in  std_logic;
        rst                : in  std_logic;
        intrusion_detected : in  std_logic;
        code_ready         : in  std_logic;
        code_match         : in  std_logic;

        enable_press       : out std_logic;
        clear_code         : out std_logic;
        alarm_siren        : out std_logic;
        system_armed       : out std_logic;

        attempts           : out integer range 0 to 7;
        state_code         : out std_logic_vector(2 downto 0)
    );
end alarm_Control;

architecture rtl of alarm_Control is

    type state_type is (DISARMED, ARMED, ALARM, LOCKED);
    signal current_state, next_state : state_type := ARMED;

    signal attempts_int, attempts_next : integer range 0 to 7 := 0;

    constant LOCK_CYCLES : integer := 5;
    signal lock_cnt_int, lock_cnt_next : integer range 0 to LOCK_CYCLES := 0;

    -- Siren latch: once alarm is activated, rst must NOT stop the siren.
    -- Cleared only by correct code.
    signal siren_latched : std_logic := '0';

    -- Maximun wrong attempts
    constant MAX_WRONG_ATTEMPTS : integer := 7;

    -- Internal outputs
    signal enable_press_i : std_logic := '0';
    signal clear_code_i   : std_logic := '0';
    signal alarm_siren_i  : std_logic := '0';
    signal system_armed_i : std_logic := '0';

    -- Used to set siren latch due to wrong attempts reaching 7
    signal set_siren_from_wrong : std_logic := '0';

	 signal state_code_i : std_logic_vector(2 downto 0);

begin

    -- Siren latch (NO async reset) - reset must not stop alarm once activated
    -- Set by intrusion OR by reaching 7 wrong attempts.
    -- Cleared only by correct code.
    process(clk)
    begin
        if rising_edge(clk) then
            if (intrusion_detected = '1') or (set_siren_from_wrong = '1') then
                siren_latched <= '1';
            elsif (code_ready = '1' and code_match = '1') then
                siren_latched <= '0';
            end if;
        end if;
    end process;

    -- State registers (async reset)
    process(clk, rst)
    begin
        if rst = '1' then
            current_state <= ARMED;   -- armed after reset
            attempts_int  <= 0;
            lock_cnt_int  <= 0;
        elsif rising_edge(clk) then
            current_state <= next_state;
            attempts_int  <= attempts_next;
            lock_cnt_int  <= lock_cnt_next;
        end if;
    end process;

    -- FSM combinational logic
    process(current_state, intrusion_detected, code_ready, code_match,
            attempts_int, lock_cnt_int, siren_latched)
        variable wrong_next : integer range 0 to 7;
    begin
        -- defaults
        next_state    <= current_state;
        attempts_next <= attempts_int;
        lock_cnt_next <= lock_cnt_int;

        enable_press_i <= '0';
        clear_code_i   <= '0';
        system_armed_i <= '0';

        set_siren_from_wrong <= '0';

        wrong_next := attempts_int;

        -- Alarm output is ON in ALARM/LOCKED or if latched
        if (current_state = ALARM) or (current_state = LOCKED) or (siren_latched = '1') then
            alarm_siren_i <= '1';
        else
            alarm_siren_i <= '0';
        end if;

        case current_state is

            when DISARMED =>
                system_armed_i <= '0';
                enable_press_i <= '1';

                if code_ready = '1' then
                    clear_code_i <= '1';

                    if code_match = '1' then
                        next_state    <= ARMED;
                        attempts_next <= 0;
                    else
                        -- wrong attempt
                        if attempts_int < 7 then
                            wrong_next := attempts_int + 1;
                        end if;
                        attempts_next <= wrong_next;

                        -- Reaching 7 wrong attempts triggers alarm/lock immediately (even when DISARMED)
                        if wrong_next >= MAX_WRONG_ATTEMPTS then
                            set_siren_from_wrong <= '1';
                            next_state    <= LOCKED;
                            lock_cnt_next <= 0;
                        end if;
                    end if;
                end if;

            when ARMED =>
                system_armed_i <= '1';
                enable_press_i <= '1';

                if intrusion_detected = '1' then
                    next_state    <= ALARM;
                    attempts_next <= 0;

                elsif code_ready = '1' then
                    clear_code_i <= '1';

                    if code_match = '1' then
                        next_state    <= DISARMED;
                        attempts_next <= 0;
                    else
                        -- wrong attempt
                        if attempts_int < 7 then
                            wrong_next := attempts_int + 1;
                        end if;
                        attempts_next <= wrong_next;

                        if wrong_next >= MAX_WRONG_ATTEMPTS then
                            set_siren_from_wrong <= '1';
                            next_state    <= LOCKED;
                            lock_cnt_next <= 0;
                        end if;
                    end if;
                end if;

            when ALARM =>
                system_armed_i <= '1';
                enable_press_i <= '1';

                if code_ready = '1' then
                    clear_code_i <= '1';

                    if code_match = '1' then
                        next_state    <= DISARMED;
                        attempts_next <= 0;
                    else
                        -- wrong attempt while in alarm
                        if attempts_int < 7 then
                            wrong_next := attempts_int + 1;
                        end if;
                        attempts_next <= wrong_next;

                        if wrong_next >= MAX_WRONG_ATTEMPTS then
                            set_siren_from_wrong <= '1';
                            next_state    <= LOCKED;
                            lock_cnt_next <= 0;
                        end if;
                    end if;
                end if;

            when LOCKED =>
                system_armed_i <= '1';
                enable_press_i <= '0';

                if lock_cnt_int < LOCK_CYCLES then
                    lock_cnt_next <= lock_cnt_int + 1;
                else
                    lock_cnt_next <= 0;
                    attempts_next <= 0;

                    -- go back to ALARM if siren still latched, else ARMED
                    if siren_latched = '1' then
                        next_state <= ALARM;
                    else
                        next_state <= ARMED;
                    end if;
                end if;

        end case;
    end process;
	 
    -- Outputs with 'Z' during reset
     with current_state select
    state_code_i <= "000" when DISARMED,
                    "001" when ARMED,
                    "010" when ALARM,
                    "011" when LOCKED,
						  "000" when others;
						  
	 enable_press <= 'Z' when rst = '1' else enable_press_i;
    clear_code   <= 'Z' when rst = '1' else clear_code_i;
    alarm_siren  <= 'Z' when rst = '1' else alarm_siren_i;
    system_armed <= 'Z' when rst = '1' else system_armed_i;

	 state_code <= "ZZZ" when rst = '1' else state_code_i;
    attempts     <= attempts_int;

end rtl;
