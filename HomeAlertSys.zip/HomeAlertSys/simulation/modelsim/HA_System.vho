-- Copyright (C) 2020  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and any partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details, at
-- https://fpgasoftware.intel.com/eula.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 20.1.1 Build 720 11/11/2020 SJ Lite Edition"

-- DATE "12/04/2025 18:17:36"

-- 
-- Device: Altera 5CGXFC7C7F23C8 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY ALTERA_LNSIM;
LIBRARY CYCLONEV;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE ALTERA_LNSIM.ALTERA_LNSIM_COMPONENTS.ALL;
USE CYCLONEV.CYCLONEV_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	Code_register IS
    PORT (
	clk : IN std_logic;
	rst : IN std_logic;
	bit_in : IN std_logic;
	valid : IN std_logic;
	code_ready : BUFFER std_logic;
	code_match : BUFFER std_logic;
	code_vector : BUFFER std_logic_vector(7 DOWNTO 0)
	);
END Code_register;

-- Design Ports Information
-- code_ready	=>  Location: PIN_M18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- code_match	=>  Location: PIN_K17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- code_vector[0]	=>  Location: PIN_N21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- code_vector[1]	=>  Location: PIN_M21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- code_vector[2]	=>  Location: PIN_K21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- code_vector[3]	=>  Location: PIN_L17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- code_vector[4]	=>  Location: PIN_M20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- code_vector[5]	=>  Location: PIN_N16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- code_vector[6]	=>  Location: PIN_N19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- code_vector[7]	=>  Location: PIN_N20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- valid	=>  Location: PIN_K22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk	=>  Location: PIN_M16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rst	=>  Location: PIN_L19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- bit_in	=>  Location: PIN_L18,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF Code_register IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk : std_logic;
SIGNAL ww_rst : std_logic;
SIGNAL ww_bit_in : std_logic;
SIGNAL ww_valid : std_logic;
SIGNAL ww_code_ready : std_logic;
SIGNAL ww_code_match : std_logic;
SIGNAL ww_code_vector : std_logic_vector(7 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_GND~I_combout\ : std_logic;
SIGNAL \clk~input_o\ : std_logic;
SIGNAL \clk~inputCLKENA0_outclk\ : std_logic;
SIGNAL \valid~input_o\ : std_logic;
SIGNAL \bit_count[0]~2_combout\ : std_logic;
SIGNAL \rst~input_o\ : std_logic;
SIGNAL \bit_count[1]~1_combout\ : std_logic;
SIGNAL \bit_count[2]~0_combout\ : std_logic;
SIGNAL \code_ready_int~0_combout\ : std_logic;
SIGNAL \code_ready_int~q\ : std_logic;
SIGNAL \bit_in~input_o\ : std_logic;
SIGNAL \Equal0~0_combout\ : std_logic;
SIGNAL \code_vector_int[1]~feeder_combout\ : std_logic;
SIGNAL \code_vector_int[3]~feeder_combout\ : std_logic;
SIGNAL \code_match_int~0_combout\ : std_logic;
SIGNAL \code_match_int~1_combout\ : std_logic;
SIGNAL \code_match_int~q\ : std_logic;
SIGNAL \code_vector_int[7]~feeder_combout\ : std_logic;
SIGNAL code_vector_int : std_logic_vector(7 DOWNTO 0);
SIGNAL bit_count : std_logic_vector(3 DOWNTO 0);
SIGNAL ALT_INV_code_vector_int : std_logic_vector(6 DOWNTO 0);
SIGNAL ALT_INV_bit_count : std_logic_vector(2 DOWNTO 0);
SIGNAL \ALT_INV_Equal0~0_combout\ : std_logic;
SIGNAL \ALT_INV_code_match_int~0_combout\ : std_logic;
SIGNAL \ALT_INV_valid~input_o\ : std_logic;
SIGNAL \ALT_INV_rst~input_o\ : std_logic;
SIGNAL \ALT_INV_bit_in~input_o\ : std_logic;
SIGNAL \ALT_INV_code_match_int~q\ : std_logic;
SIGNAL \ALT_INV_code_ready_int~q\ : std_logic;

BEGIN

ww_clk <= clk;
ww_rst <= rst;
ww_bit_in <= bit_in;
ww_valid <= valid;
code_ready <= ww_code_ready;
code_match <= ww_code_match;
code_vector <= ww_code_vector;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
ALT_INV_code_vector_int(1) <= NOT code_vector_int(1);
ALT_INV_code_vector_int(2) <= NOT code_vector_int(2);
ALT_INV_code_vector_int(3) <= NOT code_vector_int(3);
ALT_INV_code_vector_int(4) <= NOT code_vector_int(4);
ALT_INV_code_vector_int(5) <= NOT code_vector_int(5);
ALT_INV_code_vector_int(6) <= NOT code_vector_int(6);
ALT_INV_bit_count(2) <= NOT bit_count(2);
ALT_INV_bit_count(0) <= NOT bit_count(0);
ALT_INV_bit_count(1) <= NOT bit_count(1);
\ALT_INV_Equal0~0_combout\ <= NOT \Equal0~0_combout\;
\ALT_INV_code_match_int~0_combout\ <= NOT \code_match_int~0_combout\;
\ALT_INV_valid~input_o\ <= NOT \valid~input_o\;
\ALT_INV_rst~input_o\ <= NOT \rst~input_o\;
\ALT_INV_bit_in~input_o\ <= NOT \bit_in~input_o\;
ALT_INV_code_vector_int(0) <= NOT code_vector_int(0);
\ALT_INV_code_match_int~q\ <= NOT \code_match_int~q\;
\ALT_INV_code_ready_int~q\ <= NOT \code_ready_int~q\;

-- Location: IOOBUF_X89_Y36_N22
\code_ready~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \code_ready_int~q\,
	devoe => ww_devoe,
	o => ww_code_ready);

-- Location: IOOBUF_X89_Y37_N5
\code_match~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \code_match_int~q\,
	devoe => ww_devoe,
	o => ww_code_match);

-- Location: IOOBUF_X89_Y35_N96
\code_vector[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => code_vector_int(0),
	devoe => ww_devoe,
	o => ww_code_vector(0));

-- Location: IOOBUF_X89_Y37_N56
\code_vector[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => code_vector_int(1),
	devoe => ww_devoe,
	o => ww_code_vector(1));

-- Location: IOOBUF_X89_Y38_N39
\code_vector[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => code_vector_int(2),
	devoe => ww_devoe,
	o => ww_code_vector(2));

-- Location: IOOBUF_X89_Y37_N22
\code_vector[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => code_vector_int(3),
	devoe => ww_devoe,
	o => ww_code_vector(3));

-- Location: IOOBUF_X89_Y37_N39
\code_vector[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => code_vector_int(4),
	devoe => ww_devoe,
	o => ww_code_vector(4));

-- Location: IOOBUF_X89_Y35_N45
\code_vector[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => code_vector_int(5),
	devoe => ww_devoe,
	o => ww_code_vector(5));

-- Location: IOOBUF_X89_Y36_N5
\code_vector[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => code_vector_int(6),
	devoe => ww_devoe,
	o => ww_code_vector(6));

-- Location: IOOBUF_X89_Y35_N79
\code_vector[7]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => code_vector_int(7),
	devoe => ww_devoe,
	o => ww_code_vector(7));

-- Location: IOIBUF_X89_Y35_N61
\clk~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk,
	o => \clk~input_o\);

-- Location: CLKCTRL_G10
\clk~inputCLKENA0\ : cyclonev_clkena
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	disable_mode => "low",
	ena_register_mode => "always enabled",
	ena_register_power_up => "high",
	test_syn => "high")
-- pragma translate_on
PORT MAP (
	inclk => \clk~input_o\,
	outclk => \clk~inputCLKENA0_outclk\);

-- Location: IOIBUF_X89_Y38_N55
\valid~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_valid,
	o => \valid~input_o\);

-- Location: LABCELL_X88_Y37_N9
\bit_count[0]~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \bit_count[0]~2_combout\ = ( !bit_count(0) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111000000000000000011111111111111110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => ALT_INV_bit_count(0),
	combout => \bit_count[0]~2_combout\);

-- Location: IOIBUF_X89_Y38_N4
\rst~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_rst,
	o => \rst~input_o\);

-- Location: FF_X88_Y37_N11
\bit_count[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \bit_count[0]~2_combout\,
	clrn => \ALT_INV_rst~input_o\,
	ena => \valid~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => bit_count(0));

-- Location: LABCELL_X88_Y37_N30
\bit_count[1]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \bit_count[1]~1_combout\ = ( bit_count(1) & ( bit_count(0) & ( !\valid~input_o\ ) ) ) # ( !bit_count(1) & ( bit_count(0) & ( \valid~input_o\ ) ) ) # ( bit_count(1) & ( !bit_count(0) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100110011001100111100110011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_valid~input_o\,
	datae => ALT_INV_bit_count(1),
	dataf => ALT_INV_bit_count(0),
	combout => \bit_count[1]~1_combout\);

-- Location: FF_X88_Y37_N32
\bit_count[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \bit_count[1]~1_combout\,
	clrn => \ALT_INV_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => bit_count(1));

-- Location: LABCELL_X88_Y37_N15
\bit_count[2]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \bit_count[2]~0_combout\ = ( bit_count(2) & ( bit_count(0) & ( (!\valid~input_o\) # (!bit_count(1)) ) ) ) # ( !bit_count(2) & ( bit_count(0) & ( (\valid~input_o\ & bit_count(1)) ) ) ) # ( bit_count(2) & ( !bit_count(0) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000101000001011111101011111010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_valid~input_o\,
	datac => ALT_INV_bit_count(1),
	datae => ALT_INV_bit_count(2),
	dataf => ALT_INV_bit_count(0),
	combout => \bit_count[2]~0_combout\);

-- Location: FF_X88_Y37_N17
\bit_count[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \bit_count[2]~0_combout\,
	clrn => \ALT_INV_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => bit_count(2));

-- Location: LABCELL_X88_Y37_N36
\code_ready_int~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \code_ready_int~0_combout\ = ( bit_count(0) & ( (\valid~input_o\ & (((bit_count(2) & bit_count(1))) # (\code_ready_int~q\))) ) ) # ( !bit_count(0) & ( (\valid~input_o\ & \code_ready_int~q\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000001010101000000000101010100000001010101010000000101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_valid~input_o\,
	datab => ALT_INV_bit_count(2),
	datac => ALT_INV_bit_count(1),
	datad => \ALT_INV_code_ready_int~q\,
	dataf => ALT_INV_bit_count(0),
	combout => \code_ready_int~0_combout\);

-- Location: FF_X88_Y37_N37
code_ready_int : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \code_ready_int~0_combout\,
	clrn => \ALT_INV_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \code_ready_int~q\);

-- Location: IOIBUF_X89_Y38_N21
\bit_in~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_bit_in,
	o => \bit_in~input_o\);

-- Location: FF_X88_Y37_N53
\code_vector_int[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	asdata => \bit_in~input_o\,
	clrn => \ALT_INV_rst~input_o\,
	sload => VCC,
	ena => \valid~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => code_vector_int(0));

-- Location: LABCELL_X88_Y37_N39
\Equal0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \Equal0~0_combout\ = ( bit_count(0) & ( (bit_count(2) & bit_count(1)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000011000000110000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => ALT_INV_bit_count(2),
	datac => ALT_INV_bit_count(1),
	dataf => ALT_INV_bit_count(0),
	combout => \Equal0~0_combout\);

-- Location: LABCELL_X88_Y37_N21
\code_vector_int[1]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \code_vector_int[1]~feeder_combout\ = ( code_vector_int(0) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => ALT_INV_code_vector_int(0),
	combout => \code_vector_int[1]~feeder_combout\);

-- Location: FF_X88_Y37_N23
\code_vector_int[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \code_vector_int[1]~feeder_combout\,
	clrn => \ALT_INV_rst~input_o\,
	ena => \valid~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => code_vector_int(1));

-- Location: FF_X88_Y37_N56
\code_vector_int[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	asdata => code_vector_int(1),
	clrn => \ALT_INV_rst~input_o\,
	sload => VCC,
	ena => \valid~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => code_vector_int(2));

-- Location: LABCELL_X88_Y37_N3
\code_vector_int[3]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \code_vector_int[3]~feeder_combout\ = ( code_vector_int(2) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => ALT_INV_code_vector_int(2),
	combout => \code_vector_int[3]~feeder_combout\);

-- Location: FF_X88_Y37_N5
\code_vector_int[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \code_vector_int[3]~feeder_combout\,
	clrn => \ALT_INV_rst~input_o\,
	ena => \valid~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => code_vector_int(3));

-- Location: FF_X88_Y37_N44
\code_vector_int[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	asdata => code_vector_int(3),
	clrn => \ALT_INV_rst~input_o\,
	sload => VCC,
	ena => \valid~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => code_vector_int(4));

-- Location: FF_X88_Y37_N59
\code_vector_int[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	asdata => code_vector_int(4),
	clrn => \ALT_INV_rst~input_o\,
	sload => VCC,
	ena => \valid~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => code_vector_int(5));

-- Location: FF_X88_Y37_N50
\code_vector_int[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	asdata => code_vector_int(5),
	clrn => \ALT_INV_rst~input_o\,
	sload => VCC,
	ena => \valid~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => code_vector_int(6));

-- Location: LABCELL_X88_Y37_N51
\code_match_int~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \code_match_int~0_combout\ = ( !code_vector_int(2) & ( !code_vector_int(6) & ( (!code_vector_int(3) & (!code_vector_int(4) & (!code_vector_int(5) & !code_vector_int(1)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000000000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => ALT_INV_code_vector_int(3),
	datab => ALT_INV_code_vector_int(4),
	datac => ALT_INV_code_vector_int(5),
	datad => ALT_INV_code_vector_int(1),
	datae => ALT_INV_code_vector_int(2),
	dataf => ALT_INV_code_vector_int(6),
	combout => \code_match_int~0_combout\);

-- Location: LABCELL_X88_Y37_N24
\code_match_int~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \code_match_int~1_combout\ = ( \code_match_int~q\ & ( \code_match_int~0_combout\ & ( (!\valid~input_o\) # ((!\Equal0~0_combout\) # ((!\bit_in~input_o\ & !code_vector_int(0)))) ) ) ) # ( !\code_match_int~q\ & ( \code_match_int~0_combout\ & ( 
-- (!\bit_in~input_o\ & (\valid~input_o\ & (!code_vector_int(0) & \Equal0~0_combout\))) ) ) ) # ( \code_match_int~q\ & ( !\code_match_int~0_combout\ & ( (!\valid~input_o\) # (!\Equal0~0_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111100110000000000001000001111111111101100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_bit_in~input_o\,
	datab => \ALT_INV_valid~input_o\,
	datac => ALT_INV_code_vector_int(0),
	datad => \ALT_INV_Equal0~0_combout\,
	datae => \ALT_INV_code_match_int~q\,
	dataf => \ALT_INV_code_match_int~0_combout\,
	combout => \code_match_int~1_combout\);

-- Location: FF_X88_Y37_N25
code_match_int : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \code_match_int~1_combout\,
	clrn => \ALT_INV_rst~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \code_match_int~q\);

-- Location: LABCELL_X88_Y37_N45
\code_vector_int[7]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \code_vector_int[7]~feeder_combout\ = ( code_vector_int(6) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => ALT_INV_code_vector_int(6),
	combout => \code_vector_int[7]~feeder_combout\);

-- Location: FF_X88_Y37_N46
\code_vector_int[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \code_vector_int[7]~feeder_combout\,
	clrn => \ALT_INV_rst~input_o\,
	ena => \valid~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => code_vector_int(7));

-- Location: MLABCELL_X6_Y32_N0
\~QUARTUS_CREATED_GND~I\ : cyclonev_lcell_comb
-- Equation(s):

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
;
END structure;


