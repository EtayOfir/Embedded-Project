transcript on
if {[file exists gate_work]} {
	vdel -lib gate_work -all
}
vlib gate_work
vmap work gate_work

vcom -93 -work work {HA_System.vho}

vcom -93 -work work {C:/intelFPGA_lite/20.1/HomeAlertSys/Code_register_TB.vhd}

vsim -t 1ps -L altera -L altera_lnsim -L cyclonev -L gate_work -L work -voptargs="+acc"  Code_register_TB

add wave *
view structure
view signals
run -all
